# Zyro Chat — marketing / investor demo site

React + Vite + TypeScript · Tailwind CSS · Framer Motion · Three.js (@react-three/fiber + drei) · Lucide

## Run it
```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build → dist/
npm run preview   # serve the production build
```
Requires Node 18+. Fonts are self-hosted (Fontsource), so the site works offline, which helps in a pitch room with bad Wi-Fi.

## Where things live
| What | File |
|---|---|
| Brand tokens (colours, as CSS variables) | `src/index.css` (`:root`) |
| Tailwind mapping, type scale, shadows, spacing | `tailwind.config.ts` |
| **The 12 AI employees**: profiles, demo-video scripts, chat tasks & replies | `src/data/agents.ts` |
| Employee avatars (swap any file, same name) | `src/assets/agents/<id>.svg` (png/webp/jpg also work) |
| Other copy + mock data (hero, contact email, testimonials…) | `src/data/content.ts` |
| Agent workspace (modal, demo player, chat, deliverables) | `src/components/agents/*` |
| Section order | `src/App.tsx` |
| One component per section | `src/components/sections/*` |
| 3D hero scene | `src/components/three/NeuralNetwork.tsx` |
| Static fallback for the 3D scene | `src/components/three/StaticOrb.tsx` |
| Shared animation variants | `src/lib/motion.ts` |

**Brand:** Zyro Blue `#3346FF` (primary) · Ion Cyan `#18C5F2` (accent) · off-white base `#FAFBFF`.
Type: Space Grotesk (display) + Inter (body) + JetBrains Mono (labels).

## AI employee workspace
- Click any employee card to open their workspace, or link to one directly with `#agent/<id>` (e.g. `http://localhost:5173/#agent/aria`), which is handy for jumping straight to an agent mid-pitch.
- **Watch demo**: a scripted, code-rendered "screen recording" of the agent doing a real job (play/pause, seek, restart). Each one is driven by the agent's `demo` block in `agents.ts`.
- **Try it**: a working mock chat. The suggestion chips return realistic scripted work (tickets, emails, charts, calendars, docs). Anything typed freely gets matched to the closest task, or the agent replies with its plan. *Approve & run* / *Revise* complete the loop.
- Keyboard: ← / → switch agents, Esc closes.
- Avatars are original characters made with the DiceBear "Micah" style by Micah Lanier (CC BY 4.0). Keep the credit in the footer, or replace the files with your own renders.

## Pricing
There's no public pricing. The **Contact** section asks prospects to email `zyrochat@gmail.com` (edit `contact` in `content.ts`). All "Book a demo" buttons open a pre-filled email.

## 3D hero
- Lazy-loaded (three.js is ~240 kB gzipped and never blocks first paint); the static SVG orb shows while it loads.
- About 8 draw calls (instanced nodes, merged line buffer, sprite halos), DPR capped at 1.75, and the render loop pauses when the scene is off-screen.
- Falls back to the static orb when the viewer prefers reduced motion, WebGL is unavailable, the device has fewer than 4 CPU cores or less than 4 GB of memory, or Save-Data is on.
- **Demo override:** add `?3d=1` to the URL to force the 3D scene (for example on a low-core laptop you're presenting from), or `?3d=0` to force the fallback.
- To swap the visual, replace the default export of `NeuralNetwork.tsx`.

## Motion and accessibility
- `MotionConfig reducedMotion="user"` plus a CSS `prefers-reduced-motion` block. With reduced motion on, the chat demo shows all its messages at once and the counters jump straight to their final values.
- All animation is transform/opacity based, and the card spotlight uses CSS variables (no React re-renders).

## Notes
All metrics, customer names, testimonials and logos are **illustrative placeholders** and are labelled on the page as demo content. Replace them before any public use.
