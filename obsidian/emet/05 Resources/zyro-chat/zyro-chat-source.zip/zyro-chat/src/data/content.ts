/**
 * All marketing copy and mock data lives here so it can be edited
 * without touching layout code. Metrics are illustrative placeholders
 * for demo purposes only.
 */
import type { LucideIcon } from 'lucide-react'
import {
  Headphones,
  PenLine,
  Megaphone,
  LineChart,
  Handshake,
  UserPlus,
  Plug,
  Zap,
  ShieldCheck,
} from 'lucide-react'

export const nav = {
  links: [
    { label: 'Product', href: '#product' },
    { label: 'AI Employees', href: '#employees' },
    { label: 'How it Works', href: '#how' },
    { label: 'Pricing', href: '#pricing' },
  ],
}

export const hero = {
  eyebrow: 'Now hiring: 6 AI specialists',
  headline: ['Hire an AI workforce', 'that runs your business'],
  sub: 'Zyro Chat gives you autonomous AI employees for support, content, ads, analytics and sales. They learn your brand, plug into your tools, and ship real work — around the clock.',
  primaryCta: 'Book a demo',
  secondaryCta: 'Meet the team',
  stats: [
    { value: 10000, suffix: '+', label: 'tasks automated daily' },
    { value: 40, suffix: '%', label: 'faster response times' },
    { value: 24, suffix: '/7', label: 'always-on coverage' },
    { value: 3, suffix: ' min', label: 'average time to hire' },
  ],
  disclaimer: 'Illustrative metrics for demo purposes.',
}

export const logos = ['Northwind', 'Lumora', 'Kestrel', 'Halcyon', 'Parcel&Co', 'Veridian', 'Orbitly', 'Fernhill']

export type Employee = {
  id: string
  name: string
  role: string
  icon: LucideIcon
  blurb: string
  hue: [string, string] // avatar gradient stops
  skills: string[]
  sample: { prompt: string; output: string }
  kpi: string
}

export const employees: Employee[] = [
  {
    id: 'aria',
    name: 'Aria',
    role: 'Customer Support',
    icon: Headphones,
    blurb: 'Resolves tickets across chat, email and social in your brand voice — and knows when to loop in a human.',
    hue: ['#3346FF', '#18C5F2'],
    skills: ['Zendesk', 'Gorgias', 'Shopify'],
    sample: {
      prompt: '“Where is my order #4821?”',
      output: 'Looked up tracking, shared ETA (Thu), offered 10% off for the delay. Ticket closed in 38s.',
    },
    kpi: '82% tickets auto-resolved',
  },
  {
    id: 'milo',
    name: 'Milo',
    role: 'Content & SEO',
    icon: PenLine,
    blurb: 'Plans, writes and publishes search-optimized articles, product copy and newsletters every week.',
    hue: ['#6A7CFF', '#A5B4FF'],
    skills: ['WordPress', 'Webflow', 'Ahrefs'],
    sample: {
      prompt: 'Brief: “fall capsule wardrobe” blog',
      output: '1,800-word draft, 12 internal links, meta + FAQ schema. Targeting 3 keywords at KD < 25.',
    },
    kpi: '3.4× organic traffic in 90 days',
  },
  {
    id: 'nova',
    name: 'Nova',
    role: 'Ad Creative',
    icon: Megaphone,
    blurb: 'Generates, tests and iterates ad concepts for Meta, TikTok and Google — pausing losers automatically.',
    hue: ['#18C5F2', '#7DDEFA'],
    skills: ['Meta Ads', 'TikTok', 'Google Ads'],
    sample: {
      prompt: 'New angles for the linen collection',
      output: '9 hooks, 3 UGC scripts and 6 static variants queued for A/B test with $150/day budget.',
    },
    kpi: '−31% cost per acquisition',
  },
  {
    id: 'kai',
    name: 'Kai',
    role: 'Data Analyst',
    icon: LineChart,
    blurb: 'Connects your data, spots anomalies before you do and delivers the Monday report you actually read.',
    hue: ['#1D26C4', '#3346FF'],
    skills: ['GA4', 'Stripe', 'BigQuery'],
    sample: {
      prompt: 'Why did revenue dip on Tuesday?',
      output: 'Checkout error on Safari iOS 18 cut conversion 22%. Flagged to eng with a repro + impact estimate.',
    },
    kpi: '6 hrs/week of reporting saved',
  },
  {
    id: 'sage',
    name: 'Sage',
    role: 'Sales Assistant',
    icon: Handshake,
    blurb: 'Qualifies inbound leads, personalizes outreach and books meetings straight onto your calendar.',
    hue: ['#3CCFF7', '#3346FF'],
    skills: ['HubSpot', 'Gmail', 'Calendly'],
    sample: {
      prompt: '42 new demo requests overnight',
      output: 'Scored & enriched all 42, sent tailored replies, booked 11 calls. CRM updated.',
    },
    kpi: '2.1× more meetings booked',
  },
]

/* ---------------- Product demo chat script ---------------- */
export type ChatMessage =
  | { from: 'user'; text: string }
  | { from: 'ai'; text: string; card?: 'report' }
  | { from: 'task'; text: string }

export const demoScript: ChatMessage[] = [
  { from: 'user', text: 'Hey Kai — how did last week’s spring campaign perform?' },
  {
    from: 'ai',
    text: 'Revenue from the campaign hit $48.2k, up 27% week-over-week. Meta drove most of it; TikTok CPA is creeping up.',
    card: 'report',
  },
  { from: 'user', text: 'Nice. Shift 20% of TikTok budget to Meta and brief Nova on new hooks.' },
  { from: 'ai', text: 'On it. Budget rebalanced and Nova has a brief with the top 3 performing angles. I’ll check results Friday.' },
  { from: 'task', text: 'Budget updated · Brief sent to Nova · Reminder set for Fri 9:00' },
]

export const demoSidebar = [
  { name: 'Kai', role: 'Data Analyst', status: 'Active', active: true },
  { name: 'Aria', role: 'Support', status: '12 tickets', active: false },
  { name: 'Nova', role: 'Ad Creative', status: 'Testing', active: false },
  { name: 'Milo', role: 'Content', status: 'Drafting', active: false },
  { name: 'Sage', role: 'Sales', status: '3 calls', active: false },
]

/* ---------------- How it works ---------------- */
export const steps = [
  {
    icon: UserPlus,
    title: 'Hire your employee',
    body: 'Pick a specialist, give them a name and a goal. They absorb your docs, site and past tickets in minutes.',
  },
  {
    icon: Plug,
    title: 'Connect your tools',
    body: 'One-click integrations with 120+ apps — Shopify, HubSpot, Slack, Meta, GA4 — with scoped, revocable permissions.',
  },
  {
    icon: Zap,
    title: 'They get to work',
    body: 'Employees execute autonomously, collaborate with each other, and report progress in your Slack or inbox.',
  },
  {
    icon: ShieldCheck,
    title: 'You review & scale',
    body: 'Approve high-stakes actions, tune guardrails, and add headcount in a click as the results compound.',
  },
]

/* ---------------- Use cases ---------------- */
export const caseStudies = [
  {
    company: 'Lumora Skincare',
    segment: 'DTC e-commerce · 40 staff',
    employee: 'Aria',
    headline: 'Support backlog cleared in a weekend',
    before: { label: 'First response', value: '9h 40m' },
    after: { label: 'First response', value: '42s' },
    metrics: [
      { value: '82%', label: 'tickets auto-resolved' },
      { value: '+18', label: 'CSAT points' },
    ],
  },
  {
    company: 'Kestrel Outdoor',
    segment: 'Retail · 3 markets',
    employee: 'Nova + Kai',
    headline: 'Paid social that optimizes itself',
    before: { label: 'Blended ROAS', value: '1.9×' },
    after: { label: 'Blended ROAS', value: '3.2×' },
    metrics: [
      { value: '−31%', label: 'cost per acquisition' },
      { value: '140', label: 'creatives tested / mo' },
    ],
  },
  {
    company: 'Halcyon Labs',
    segment: 'B2B SaaS · Series A',
    employee: 'Sage',
    headline: 'Pipeline doubled without new hires',
    before: { label: 'Meetings / month', value: '38' },
    after: { label: 'Meetings / month', value: '81' },
    metrics: [
      { value: '2.1×', label: 'meetings booked' },
      { value: '< 2 min', label: 'lead response time' },
    ],
  },
]

/* ---------------- Testimonials ---------------- */
export const testimonials = [
  {
    quote:
      'We replaced three different tools and a night-shift contractor with Aria. Customers genuinely can’t tell — they just notice we’re faster.',
    name: 'Priya Raman',
    title: 'Head of CX, Lumora',
  },
  {
    quote:
      'Nova ships more creative in a week than our agency did in a quarter, and Kai tells us which ones actually made money. It’s a growth team in a tab.',
    name: 'Marcus Oyelaran',
    title: 'Founder, Kestrel Outdoor',
  },
  {
    quote:
      'The guardrails sold me. Everything risky waits for approval, everything routine just happens. Our team finally works on the interesting problems.',
    name: 'Elena Duarte',
    title: 'COO, Halcyon Labs',
  },
  {
    quote:
      'Onboarding took an afternoon. By Monday Milo had a content calendar, four drafts and a keyword map. I’ve never seen time-to-value like it.',
    name: 'James Whitfield',
    title: 'Marketing Lead, Orbitly',
  },
]

/* ---------------- Pricing ---------------- */
export const pricing = [
  {
    name: 'Starter',
    price: 49,
    blurb: 'For founders hiring their first AI teammate.',
    features: ['1 AI employee', '1,000 tasks / month', '10 integrations', 'Email support'],
    cta: 'Start free trial',
    popular: false,
  },
  {
    name: 'Growth',
    price: 199,
    blurb: 'For teams scaling support, content and ads.',
    features: ['5 AI employees', '15,000 tasks / month', 'All 120+ integrations', 'Team collaboration & approvals', 'Priority support'],
    cta: 'Start free trial',
    popular: true,
  },
  {
    name: 'Scale',
    price: null,
    blurb: 'For companies running operations on AI.',
    features: ['Unlimited employees', 'Custom task volume', 'SSO, audit logs & SOC 2 report', 'Dedicated success manager'],
    cta: 'Talk to sales',
    popular: false,
  },
]

export const footer = {
  columns: [
    { title: 'Product', links: ['AI Employees', 'Integrations', 'Security', 'Changelog'] },
    { title: 'Company', links: ['About', 'Careers', 'Press', 'Contact'] },
    { title: 'Resources', links: ['Docs', 'Guides', 'Community', 'Status'] },
  ],
}
