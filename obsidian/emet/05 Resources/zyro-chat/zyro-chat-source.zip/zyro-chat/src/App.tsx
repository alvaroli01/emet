import { MotionConfig } from 'framer-motion'
import { Nav } from './components/sections/Nav'
import { Hero } from './components/sections/Hero'
import { LogoStrip } from './components/sections/LogoStrip'
import { Employees } from './components/sections/Employees'
import { ProductDemo } from './components/sections/ProductDemo'
import { HowItWorks } from './components/sections/HowItWorks'
import { UseCases } from './components/sections/UseCases'
import { Testimonials } from './components/sections/Testimonials'
import { Pricing } from './components/sections/Pricing'
import { FinalCTA } from './components/sections/FinalCTA'
import { Footer } from './components/sections/Footer'

/** Reorder or remove sections here. */
export default function App() {
  return (
    // reducedMotion="user" makes every Framer animation honour prefers-reduced-motion
    <MotionConfig reducedMotion="user">
      <Nav />
      <main>
        <Hero />
        <LogoStrip />
        <Employees />
        <ProductDemo />
        <HowItWorks />
        <UseCases />
        <Testimonials />
        <Pricing />
        <FinalCTA />
      </main>
      <Footer />
    </MotionConfig>
  )
}
