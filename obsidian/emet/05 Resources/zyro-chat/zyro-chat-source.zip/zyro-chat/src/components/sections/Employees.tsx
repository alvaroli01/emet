import { motion } from 'framer-motion'
import { ArrowUpRight, CornerDownRight, Plus, Sparkles } from 'lucide-react'
import type { MouseEvent } from 'react'
import { employees, type Employee } from '../../data/content'
import { EmployeeAvatar } from '../ui/EmployeeAvatar'
import { SectionHeader } from '../ui/SectionHeader'
import { fadeUp, inView, stagger } from '../../lib/motion'

/** Cursor-following spotlight via CSS vars — no React re-render */
function trackSpotlight(e: MouseEvent<HTMLElement>) {
  const r = e.currentTarget.getBoundingClientRect()
  e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`)
  e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`)
}

function EmployeeCard({ e }: { e: Employee }) {
  const Icon = e.icon
  return (
    <motion.article
      variants={fadeUp}
      onMouseMove={trackSpotlight}
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-ink-200/80 bg-ink-0 p-6 shadow-card transition-[border-color,box-shadow,transform] duration-500 ease-out-expo hover:-translate-y-1 hover:border-brand-300 hover:shadow-lift sm:p-7"
    >
      {/* spotlight */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background: 'radial-gradient(380px circle at var(--mx) var(--my), rgb(var(--brand-500) / 0.08), transparent 60%)',
        }}
      />

      <header className="relative flex items-start justify-between gap-4">
        <div className="flex items-center gap-4">
          <EmployeeAvatar name={e.name} hue={e.hue} size={56} className="transition-transform duration-500 ease-out-expo group-hover:scale-105 group-hover:-rotate-3" />
          <div>
            <h3 className="text-display-sm font-semibold">{e.name}</h3>
            <p className="flex items-center gap-1.5 text-body-sm text-ink-500">
              <Icon className="h-3.5 w-3.5 text-brand-500" /> {e.role}
            </p>
          </div>
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-success/10 px-2.5 py-1 text-caption font-medium text-success">
          <span className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-success" /> Available
        </span>
      </header>

      <div className="relative mt-5 flex-1 lg:min-h-[7.25rem]">
        <p className="text-body-md text-ink-600 transition-all duration-500 ease-out-expo lg:group-hover:-translate-y-2 lg:group-hover:opacity-0">
          {e.blurb}
        </p>

        {/* Sample work — always visible on touch sizes, revealed on hover on desktop */}
        <div className="mt-4 rounded-2xl border border-brand-100 bg-brand-50/60 p-4 transition-all duration-500 ease-out-expo lg:absolute lg:inset-0 lg:mt-0 lg:translate-y-3 lg:opacity-0 lg:group-hover:translate-y-0 lg:group-hover:opacity-100">
          <p className="flex items-center gap-1.5 font-mono text-caption uppercase tracking-wider text-brand-600">
            <Sparkles className="h-3 w-3" /> Sample task
          </p>
          <p className="mt-2 text-body-sm font-medium text-ink-900">{e.sample.prompt}</p>
          <p className="mt-1.5 flex gap-1.5 text-body-sm text-ink-600">
            <CornerDownRight className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ion-600" />
            {e.sample.output}
          </p>
        </div>
      </div>

      <footer className="relative mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-5">
        <div className="flex flex-wrap gap-1.5">
          {e.skills.map((s) => (
            <span key={s} className="rounded-md bg-ink-50 px-2 py-1 text-caption text-ink-600">
              {s}
            </span>
          ))}
        </div>
        <span className="text-caption font-medium text-brand-600">{e.kpi}</span>
      </footer>
    </motion.article>
  )
}

export function Employees() {
  return (
    <section id="employees" className="section">
      <div className="container">
        <SectionHeader
          eyebrow="Meet the team"
          title={
            <>
              Specialists that start <span className="text-gradient">on day one</span>
            </>
          }
          sub="Each Zyro employee is trained for a single job and does it exceptionally well. Hire one, or assemble a full team that hands work off to each other."
        />

        <motion.div
          variants={stagger(0.08)}
          initial="hidden"
          whileInView="show"
          viewport={inView}
          className="mt-14 grid gap-5 sm:grid-cols-2 lg:mt-16 lg:grid-cols-3"
        >
          {employees.map((e) => (
            <EmployeeCard key={e.id} e={e} />
          ))}

          {/* Custom hire card */}
          <motion.a
            variants={fadeUp}
            href="#cta"
            className="group relative flex min-h-[18rem] flex-col justify-between overflow-hidden rounded-3xl bg-brand-gradient p-7 text-white shadow-lift"
          >
            <div aria-hidden className="absolute inset-0 bg-grid-faint bg-[size:28px_28px] opacity-40 mix-blend-overlay" />
            <div aria-hidden className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-white/20 blur-3xl transition-transform duration-700 ease-out-expo group-hover:scale-125" />
            <div className="relative">
              <span className="grid h-14 w-14 place-items-center rounded-2xl border border-white/30 bg-white/10 backdrop-blur transition-transform duration-500 group-hover:rotate-90">
                <Plus className="h-6 w-6" />
              </span>
              <h3 className="mt-5 text-display-sm font-semibold text-white">Design a custom employee</h3>
              <p className="mt-2 text-body-md text-white/80">
                Describe the role in plain English. Zyro builds the skills, tools and guardrails for you.
              </p>
            </div>
            <span className="relative mt-6 inline-flex items-center gap-1.5 font-medium">
              Start building <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </span>
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
